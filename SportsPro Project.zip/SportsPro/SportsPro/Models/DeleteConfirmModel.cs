﻿namespace SportsPro.Models
{
    public class DeleteConfirmModel
    {
        public int Id { get; set; }

        public string Name = string.Empty;
    }
}
