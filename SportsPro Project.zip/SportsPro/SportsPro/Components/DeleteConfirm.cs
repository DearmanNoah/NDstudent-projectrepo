﻿using Microsoft.AspNetCore.Mvc;
using SportsPro.Models;

namespace SportsPro.Components
{
    public class DeleteConfirm : ViewComponent
    {
        public IViewComponentResult Invoke(DeleteConfirmModel model)
        {
            return View(model);
        }
    }
}